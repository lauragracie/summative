#include <allegro5/allegro.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include "setup.h"


extern ALLEGRO_DISPLAY *display;
extern ALLEGRO_BITMAP *background;
extern ALLEGRO_BITMAP *spaceship;
extern ALLEGRO_EVENT_QUEUE *event_queue;
extern ALLEGRO_EVENT event;

void draw_background(){
    al_draw_scaled_bitmap(background,0,0,1300,1300,0,0,640,480,0);
}

void draw_spaceship(){
    al_draw_scaled_bitmap(spaceship,0,0,272,550,320,50,54,30,0);
}
