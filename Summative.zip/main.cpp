/*****************************************************************************
 *	Name:                                                                    *
 *	Date:                                                                    *
 *                                                                           *
 *	Purpose:                                                                 *
 *	                                                                         *
 *	Usage:                                                                   *
 *	                                                                         *
 *	Revision History:                                                        *
 *	                                                                         *
 *	Known Issues:                                                            *
 *	                                                                         *
 *****************************************************************************/

#include <allegro5/allegro.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include "setup.h"
const int SCREEN_W = 640;       // screen width
const int SCREEN_H = 480;

bool doexit = false;


// Initialize display
ALLEGRO_DISPLAY *display;
ALLEGRO_BITMAP *background;
ALLEGRO_BITMAP *spaceship;
ALLEGRO_EVENT_QUEUE *event_queue;
ALLEGRO_EVENT event;

int main_innitialize();
int functions_innitialize();
void draw_background();
void draw_spaceship();

// NOTE: argc, argv parameters are required.
int main(int argc, char *argv[]) {

    // Initialize Allegro
    al_init();

	main_innitialize();

	while (!doexit){
        al_wait_for_event(event_queue, &event);
        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
        	doexit = true;
      	}
        draw_background();
        draw_spaceship();
        al_flip_display();
	}

    //al_rest(5);
    // Free up memory taken by display.
    al_destroy_display(display);

    // Exit with no errors
	return 0;
}
